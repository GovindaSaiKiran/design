export interface VoiceItem {
  id: string;
  name: string;
  gender: "Female" | "Male" | "Neutral";
  language: string;
  accent: string;
  tone: "Warm & Reassuring" | "Professional Executive" | "Conversational Friendly" | "Direct & Crisp" | "Gentle & Empathetic" | "Authoritative & Crisp" | string;
  sampleAudio: string;
  latencyMs: number;
  sampleTranscript: string;
  tag?: string;
  recommendedFor: string;
  isCloned?: boolean;
  cloneFidelity?: number;
  clonedAt?: string;
  recordedAudioBlobUrl?: string;
  provider?: string;
}

export const initialClonedVoices: VoiceItem[] = [];

export const readyMadeVoices: VoiceItem[] = [
  {
    id: "ritu-hi",
    name: "Ritu",
    gender: "Female",
    language: "Hindi",
    accent: "Neutral North Indian Hindi",
    tone: "Warm & Reassuring",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 120,
    sampleTranscript: "नमस्ते! हमारे प्रवेश परामर्श केंद्र में आपका स्वागत है। मैं आपकी क्या सहायता कर सकती हूँ?",
    tag: "Most Popular",
    recommendedFor: "Admissions & Inbound Helpline",
  },
  {
    id: "maya-en",
    name: "Maya Pro",
    gender: "Female",
    language: "Indian English",
    accent: "Pan-Indian Corporate English",
    tone: "Professional Executive",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 135,
    sampleTranscript: "Hello! Welcome to the student services office. I'm here to assist you with admissions and scholarships.",
    tag: "High Accuracy",
    recommendedFor: "Corporate & Campus Advising",
  },
  {
    id: "neha-te",
    name: "Neha",
    gender: "Female",
    language: "Telugu",
    accent: "Coastal Andhra & Telangana",
    tone: "Conversational Friendly",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 128,
    sampleTranscript: "నమస్కారం! మా అడ్మిషన్ల హెల్ప్‌లైన్‌కు స్వాగతం. మీ ప్రశ్నలకు సమాధానం ఇవ్వడానికి నేను సిద్ధంగా ఉన్నాను.",
    tag: "Regional Star",
    recommendedFor: "South India Regional Outreach",
  },
  {
    id: "priya-ta",
    name: "Priya",
    gender: "Female",
    language: "Tamil",
    accent: "Standard Chennai Tamil",
    tone: "Warm & Reassuring",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 140,
    sampleTranscript: "வணக்கம்! எங்கள் பல்கலைக்கழக சேர்க்கை உதவி மையத்திற்கு வரவேற்கிறோம்.",
    recommendedFor: "Tamil Nadu Admissions",
  },
  {
    id: "ishita-kn",
    name: "Ishita",
    gender: "Female",
    language: "Kannada",
    accent: "Bangalore & Mysuru Regional",
    tone: "Warm & Reassuring",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 132,
    sampleTranscript: "ನಮಸ್ಕಾರ! ನಮ್ಮ ಸಂಸ್ಥೆಯ ಪ್ರವೇಶ ಸಹಾಯವಾಣಿಗೆ ಸುಸ್ವಾಗತ. ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?",
    recommendedFor: "Karnataka Campus Helpline",
  },
  {
    id: "shubh-hi",
    name: "Shubh",
    gender: "Male",
    language: "Hindi",
    accent: "Delhi NCR Formal Hindi",
    tone: "Direct & Crisp",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 125,
    sampleTranscript: "नमस्कार! मैं आपके प्रवेश संबंधी सभी विवरण और शुल्क संरचना साझा करने के लिए उपलब्ध हूँ।",
    recommendedFor: "Official Inquiries & Fee Queries",
  },
  {
    id: "vikram-en",
    name: "Vikram",
    gender: "Male",
    language: "Indian English",
    accent: "Executive Indian English",
    tone: "Professional Executive",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 145,
    sampleTranscript: "Good day. I am following up on your application request submitted earlier this week.",
    recommendedFor: "Outbound Lead Outreach & Verification",
  },
  {
    id: "sneha-mr",
    name: "Sneha",
    gender: "Female",
    language: "Marathi",
    accent: "Pune & Mumbai Marathi",
    tone: "Conversational Friendly",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 130,
    sampleTranscript: "नमस्कार! आमच्या शैक्षणिक प्रवेश मार्गदर्शन कक्षामध्ये आपले स्वागत आहे.",
    recommendedFor: "Maharashtra Regional Desk",
  },
  {
    id: "suhani-bn",
    name: "Suhani",
    gender: "Female",
    language: "Bengali",
    accent: "Kolkata Standard Tone",
    tone: "Warm & Reassuring",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 138,
    sampleTranscript: "নমস্কার! আমাদের ভর্তি সহায়তা হেল্পলাইনে আপনাকে স্বাগত জানাচ্ছি।",
    recommendedFor: "Eastern Region Inbound",
  },
  {
    id: "alex-us",
    name: "Alex",
    gender: "Male",
    language: "US English",
    accent: "Neutral American",
    tone: "Direct & Crisp",
    sampleAudio: "https://actions.google.com/sounds/v1/speech/female_affirmation.ogg",
    latencyMs: 110,
    sampleTranscript: "Hello there! Thank you for reaching out to our global technical support desk.",
    recommendedFor: "International Applicants & Global Support",
  },
];
